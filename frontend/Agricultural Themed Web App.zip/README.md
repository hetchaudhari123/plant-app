
  # Agricultural Themed Web App

  This is a code bundle for Agricultural Themed Web App. The original project is available at https://www.figma.com/design/1ay67CcVZCRS0vIEvhS2Tp/Agricultural-Themed-Web-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  